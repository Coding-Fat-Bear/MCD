return {
  type: "items",
  component: "accordion",
  items: {
    settings: {
      uses: "settings",
      items: {
        MySwitchProp: {
          type: "boolean",
          component: "switch",
          label: "Switch me On",
          ref: "myproperties.border",
          options: [{
            value: true,
            label: "On"
          }, {
            value: false,
            label: "Not On"
          }],
          defaultValue: true
        }
      }
    }
  }
}